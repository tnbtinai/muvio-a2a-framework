"""
Muvius Framework - A framework for building and managing AI agents
"""

__version__ = "0.1.2" 